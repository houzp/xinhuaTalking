/**
 * Copyright (c) Xinhuanet Inc. All rights reserved.
 *
 * @License: MIT
 * @Author: SuperWoods
 * @Email:  st_sister@iCloud.com
 * @Date:   2016-09-30-09:10:03
 *
 * @(demo)Last modified by:   SuperWoods
 * @(demo)Last modified time: 2016-09-30-02:35:38
 */
/*
     TIPS:
     请不要直接把这个js放到jade模版中。。。。否则jade会闹情绪的！
     嗯，正确的姿势是，打开这个地址：

     http://tool.oschina.net/jscompress

     使数组格式压缩成一行儿，然后再放进jade模版
     晚我会研究一下怎么在jade模版放折行格式的数组！
*/
// - const leaders =
[{
    title: "蔡名照",
    avatar: "caimingzhao",
    abs: "新华社社长、党组书记，中共中央委员。",
    tiny: "蔡名照会见卡塔尔通讯社社长",
    tiny_url: "http://news.xinhuanet.com/xhsld/2016-09/26/c_1119627633.htm",
    tiny_abs: "新华社北京9月26日电（记者刘华）新华社社长蔡名照26日在北京会见卡塔尔通讯社社长布艾南。"
}, {
    title: "何平",
    avatar: "heping",
    abs: "新华社总编辑、党组副书记，中央纪委委员。",
    tiny: "新华社举办“不忘初心 传承‘红色气质’”座谈会",
    tiny_url: "http://news.xinhuanet.com/xhsld/2016-09/27/c_1119635059.htm",
    tiny_abs: "新华社北京９月２７日电（记者吴晶晶）作为“两学一做”的重要活动，新华社２７日在京举办“不忘初心　传承‘红色气质’”座谈会。座谈会以新华社出品的微电影《红色气质》为切入点，部分知名“红色后代”、老一辈新华人与新华社青年采编人员就如何更好地传承“红色气质”进行了交流。"
}, {
    title: "周树春",
    avatar: "zhoushuchun",
    abs: "新华社副社长兼常务副总编辑、党组成员。",
    tiny: "“APEC蓝”倒逼，古战场再现“背水一战”",
    tiny_url: "http://news.xinhuanet.com/xhsld/2014-12/31/c_1113845036.htm",
    tiny_abs: "新华网石家庄１２月３１日电（记者周树春、李柯勇、张洪河）指令下达，炉火渐熄，飞转的汽轮机叶片缓缓降速，震耳轰鸣归于沉寂——２０１４年最后一天，华能上安电厂５号发电机组停机，开始接受长达三个月的脱硫、脱硝、除尘改造。这是上安电厂最后一台停机改造的机组。"
}, {
    title: "刘思扬",
    avatar: "liusiyang",
    abs: "新华社副社长、党组成员。",
    tiny: "聚焦科幻未来 国际科幻高峰论坛暨第七届全球华语科幻星云奖颁奖典礼在京启幕",
    tiny_url: "http://news.xinhuanet.com/2016-09/11/c_135678143.htm",
    tiny_abs: "新华网北京9月11日电（记者 商亮）9月10日下午，由新华网等主办的“科幻·中国与世界”国际科幻高峰论坛暨第七届全球华语科幻星云奖开幕式在中国国家图书馆艺术中心启幕。"
}, {
    title: "周宗敏",
    avatar: "zhouzongmin",
    abs: "新华社副总编辑、党组成员。",
    tiny: "第八届中韩媒体高层对话在韩国首尔举行",
    tiny_url: "http://news.xinhuanet.com/newmedia/2016-05/23/c_1118917461.htm",
    tiny_abs: "新华通讯社副总编辑周宗敏说，在两国关系发展中，媒体发挥着特殊而重要的作用。增进两国民众的相互了解，把中韩关系维护好、巩固好、发展好，是两国媒体共同肩负的历史使命。"
}, {
    title: "刘正荣",
    avatar: "liuzhengrong",
    abs: "新华社副社长兼秘书长、党组成员。",
    tiny: "国务院任免国家工作人员",
    tiny_url: "http://news.xinhuanet.com/politics/2016-09/14/c_1119564271.htm",
    tiny_abs: "新华社北京9月14日电 国务院任免国家工作人员。任命王贺胜为国家卫生和计划生育委员会副主任；任命刘正荣、张宿堂为新华通讯社副社长；任命薛晓峰为中央人民政府驻澳门特别行政区联络办公室副主任；任命于再清为北京2022年冬奥会和冬残奥会组织委员会副主席。"
}, {
    title: "张宿堂",
    avatar: "zhangsutang",
    abs: "新华社副社长、党组成员。",
    tiny: "新华社举办“不忘初心 传承‘红色气质’”座谈会",
    tiny_url: "http://news.xinhuanet.com/xhsld/2016-09/27/c_1119635059.htm",
    tiny_abs: "新华社北京９月２７日电（记者吴晶晶）作为“两学一做”的重要活动，新华社２７日在京举办“不忘初心　传承‘红色气质’”座谈会。座谈会以新华社出品的微电影《红色气质》为切入点，部分知名“红色后代”、老一辈新华人与新华社青年采编人员就如何更好地传承“红色气质”进行了交流。"
}, {
    title: "姚光",
    avatar: "yaoguang",
    abs: "新华社副秘书长",
    tiny: "暂无活动报道，欢迎您关注",
    tiny_url: "#",
    tiny_abs: " "
}];
