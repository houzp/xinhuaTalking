/**
 * Copyright (c) Xinhuanet Inc. All rights reserved.
 *
 * @License: MIT
 * @Author: SuperWoods
 * @Email:  st_sister@iCloud.com
 * @Date:   2016-09-18-08:55:31
 *
 * @(demo)Last modified by:   SuperWoods
 * @(demo)Last modified time: 2016-09-20-11:17:26
 */

window.BROWSER_NOJUMP = true;
// window.BROWSER_JUMPTO = 'mobile';
