/**
 * Copyright (c) Xinhuanet Inc. All rights reserved.
 *
 * @License: MIT
 * @Author: SuperWoods
 * @Email:  st_sister@iCloud.com
 * @Date:   2016-09-26-10:46:24
 *
 * @(demo)Last modified by:   SuperWoods
 * @(demo)Last modified time: 2016-09-27-08:27:53
 */

// mask
$(() => {
    // mask.js
    const $window = $(window);
    const $mask = $('#mask');
    const $modalPic = $('#mod-mask-layer');

    let size = null;

    if ($mask.length && $modalPic.length) {
        console.log('hello mask!!');
        let isAutoSize = $modalPic.data().autosize;
        console.log(isAutoSize);

        const $modalImg = $modalPic.find('img');
        const $maskIn = $mask.find('.mask-layer-in');

        // if ($modalImg.data().size) {
        // console.log($modalImg.eq(0).data().size);
        // }

        const sizeHandler = () => {
            return {
                w: $window.width(),
                h: $window.height(),
            };
        };

        const setSize = () => {
            size = sizeHandler();
        };

        $window.on('resize', () => {
            $.when(setSize()).then(() => {
                $mask.height(size.h);
                $mask.width(size.w);
            });
        });

        $mask.on('click', () => {
            $mask.removeClass('active');
        });

        // const ratioHeight = 800 * 280 / 430;
        $modalImg.each((i, e) => {
            let $e = $(e);
            // let nW = $e[0].naturalWidth;
            // let nH = $e[0].naturalHeight;
            let dom = {
                // w: (isAutoSize) ? ((nW) ? nW : 800) : 800,
                // h: (isAutoSize) ? ((nH) ? nH : ratioHeight) : ratioHeight,
                src: $e.attr('src'),
                title: $e.next().text(),
            };
            if (dom.src) {
                $e.on('click', () => {
                    if (dom.title.length) {
                        dom.title = `<p>${dom.title}</p>`;
                    } else {
                        $maskIn.addClass('no-after-bg');
                        dom.title = '';
                    }
                    // $maskIn
                    //     .css({
                    //         width: dom.w,
                    //         height: dom.h,
                    //     })
                    $maskIn.html(`<img src="${dom.src}">${dom.title}`);
                    $mask.addClass('active');
                });
            }
            // if (window.BROWSER.browser !== 'ie') {
            // }
            console.log(window.BROWSER.browser);

        });
    }
});
