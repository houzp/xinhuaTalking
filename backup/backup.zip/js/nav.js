/**
 * Copyright (c) Xinhuanet Inc. All rights reserved.
 *
 * @License: MIT
 * @Author: SuperWoods
 * @Email:  st_sister@iCloud.com
 * @Date:   2016-09-12-10:39:30
 *
 * @(demo)Last modified by:   SuperWoods
 * @(demo)Last modified time: 2016-10-08-08:34:02
 */
// nav
$(() => {
    const $window = $(window);
    let windowHeight = $window.height();
    const $document = $(document);
    let documentHeight = $document.height();

    const windowHref = window.location.href;

    const $nav = $('#nav');
    const $navA = $nav.find('a');
    const $navActive = $nav.find('.active');
    const $partLeaderBox = $('#part-leader-box');
    const $productBox = $('#product-box');
    const $historySidebarList = $('#history-sidebar-list');
    const $sidebarList = $('#sidebar-list');
    const $sidebar = $('.sidebar');
    const $content = $('.content');

    // addNavKey: 给指定模块添加 nav激活关键字
    const addNavKey = (opt) => {
        let $tag = opt.$tag;
        /*
        如果 $tag存在，
        则给下面 child href添加 key 关键字(建议使用?)，
        触发导航激活状态。
        注意：
        关键字必须在导航的 href 存在，否则无法激活导航，
        为避免重复请使用完整关键字。
        */
        if ($tag.length) {
            let child = opt.child;
            let key = opt.key;
            $tag.find(child).each((i, e) => {
                let href = $(e).attr('href');
                $(e).attr('href', `${href}${key}`);
            });
        }
    }
    const setSidebarActive = (opt) => {
        let $tag = opt.$tag;
        let windowHref = opt.windowHref;
        if ($tag.length) {
            let child = opt.child;
            let childIsArray = $.isArray(child);
            console.log(childIsArray);
            if (childIsArray) {
                child = child[1];
            }
            $tag.find(child).each((i, e) => {
                let $e = $(e);
                let href = $e.attr('href');
                let active = 'active';
                if (windowHref.lastIndexOf(href) !== -1) {
                    $tag.find(`.${active}`).removeClass(active);
                    if (childIsArray) {
                        $e.parent().addClass(active);
                    } else {
                        $e.addClass(active);
                    }
                }
            });
        }
    }
    console.log('setSidebarActive', $historySidebarList.length);
    if ($historySidebarList.length) {
        setSidebarActive({
            windowHref: windowHref,
            $tag: $historySidebarList,
            child: ['li', 'a'],
        });
    }
    console.log('$partLeaderBox:', $partLeaderBox.length);
    if ($partLeaderBox.length) {
        addNavKey({
            $tag: $partLeaderBox,
            child: 'a',
            key: '?leader'
        });
    }
    // console.log('$productBox:', $productBox.length);
    // if ($productBox.length) {
    //     addNavKey({
    //         $tag: $productBox,
    //         child: 'a',
    //         key: '?product'
    //     });
    // }
    // 给 nav的 a 添加 active
    $navA.each((i, e) => {
        let _e = $(e);
        let _eAttrHref = _e.attr('href');
        let keyHtml = _eAttrHref.replace('.html', '');
        let keyHtm = _eAttrHref.replace('.htm', '');
        if (windowHref.lastIndexOf(keyHtml) !== -1 || windowHref.lastIndexOf(keyHtm) !== -1) {
            $navActive.removeClass('active');
            _e.addClass('active');
        }
    });
    // 非开发模式 (localhost:) 添加 base _blank
    if (windowHref.indexOf('localhost:') === -1) {
        const $head = $('head');
        $head.append('<base target="_blank">');
    }

    // set sidebar
    // let scrollTop = null;
    // const bodyHeight = $('body').height();
    console.log('d', documentHeight);
    // console.log('b', bodyHeight);
    console.log('w', windowHeight);

    const setSidebar = () => {
        windowHeight = $window.height();
        documentHeight = $document.height();

        let scrollTop = null; // 窗体滚动的即时高度
        let isFixedMarginTop = false; // 如果边栏高于窗体（sidebarHeight - windowHeight）
        let $isFixed = null; // 添加了.isFixed的对象
        let footerHeight = 90; // footer高，由于他通过后面‘nav.js’写入，此处无法获取.footer
        // 边栏列表高
        let sidebarListHeight = $sidebar.find('ul').outerHeight();
        console.log('sidebarListHeight', sidebarListHeight);
        // 边栏总体高
        let sidebarHeight = $sidebar.outerHeight() + sidebarListHeight;
        console.log('sidebarHeight', sidebarHeight);
        // 边栏据窗体顶部距离
        let sidebarTop = $sidebar.offset().top;
        // 最大滚动高
        let maxScroll = documentHeight - windowHeight;
        console.log('maxScroll', maxScroll);

        // 如果边栏高 > 窗体高
        let isOverWH = (sidebarHeight + footerHeight) > windowHeight;
        console.log('isOverWH', isOverWH);

        // 如果边栏高 > 窗体高
        if (sidebarHeight > windowHeight) {
            isFixedMarginTop = sidebarHeight - windowHeight;
        }
        console.log('isFixedMarginTop', isFixedMarginTop);

        // on scroll
        $window.on('scroll', () => {
            scrollTop = $window.scrollTop();
            console.log('scrollTop', scrollTop);
            // isFixed
            let isFixed = scrollTop > sidebarTop;
            let isMeetFooter = scrollTop > maxScroll;

            if (isFixed) {
                $sidebar.addClass('isFixed');
                if (isFixedMarginTop) {
                    if ($isFixed === null) {
                        $isFixed = $('.isFixed');
                    }
                    $isFixed.css({
                        'margin-top': -isFixedMarginTop,
                    });
                }
                // isMeetFooter
                if (isMeetFooter && isOverWH) {
                    $sidebar.addClass('isMeetFooter').css({
                        bottom: sidebarListHeight,
                    });
                } else {
                    $sidebar.removeClass('isMeetFooter').css({
                        bottom: 'auto',
                    });
                }
            } else {
                $sidebar.removeClass('isFixed');
            }
        });
    }
    setSidebar();
    $window.on('resize', () => {
        setSidebar();
    });

    // sidebarList
    const setSidebar2 = ($tag) => {
        let hash = window.location.hash.replace('#', '');
        let _$tag = $tag.find(`.${hash}`);
        if (_$tag) {
            _$tag.addClass('active').siblings().removeClass('active');
        }
    };

    // const sidebarOffsetTopHandler = () => {
    //
    // };
    // if (condition) {
    //
    // }



    setSidebar2($sidebarList);
    $window.on('hashchange', () => {
        setSidebar2($sidebarList);
    });
});
