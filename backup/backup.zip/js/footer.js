/**
 * Copyright (c) Xinhuanet Inc. All rights reserved.
 *
 * @License: MIT
 * @Author: SuperWoods
 * @Email:  st_sister@iCloud.com
 * @Date:   2016-09-12-10:39:30
 *
 * @(demo)Last modified by:   SuperWoods
 * @(demo)Last modified time: 2016-09-24-11:52:52
 */
// footer
$(() => {
    const $body = $('body');
    const d = new Date();
    const year = d.getFullYear();
    $body.append(`<div class="footer">新华通讯社 Copyright © 2000-${year} Xinhua News Agency All Rights Reserved.</div>`);
});
