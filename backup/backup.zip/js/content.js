/**
 * Copyright (c) Xinhuanet Inc. All rights reserved.
 *
 * @License: MIT
 * @Author: SuperWoods
 * @Email:  st_sister@iCloud.com
 * @Date:   2016-09-12-05:22:32
 *
 * @(demo)Last modified by:   SuperWoods
 * @(demo)Last modified time: 2016-10-08-04:43:24
 */
$(() => {
    // const $historySidebarList = $('#history-sidebar-list');
    // console.log('$historySidebarList:', $historySidebarList.length);
    // if ($historySidebarList.length) {}

    // banner
    const $banner = $('#banner');
    console.log('$banner:', $banner.length);
    if ($banner.length) {
        $banner.append(`<div class="sprite sprite-title-xinhua"></div>
            <div class="sprite sprite-title-news"></div>
            <div class="sprite sprite-title-news-bg"></div>
            <div class="sprite sprite-title-agency"></div>
            <div class="building"></div>
            <div class="bg-building"></div>`);
    }

    // pic-history
    const $picHistory = $('#pic-history');
    console.log('$picHistory:', $picHistory.length);
    if ($picHistory.length) {
        const swiperHandler = ($tag) => {
            const $tagSlide = $tag.find('.swiper-slide');
            if ($tagSlide.length > 1) {
                const selector = $tag.selector;
                const $tagWrapper = $tag.find('.swiper-wrapper');
                const btnDOM = `<a class="btn-pre" href="javascript:void(0);">上一页</a>
<a class="btn-next" href="javascript:void(0);">下一页</a>`;
                const paginationDOM = '<div class="pagination"></div>';
                let swiper;
                let options = {
                    speed: 300,
                    pagination: `${selector} .pagination`,
                    keyboardControl: true,
                    paginationClickable: true,
                    autoplay: 5000,
                    loop: true,
                    progress: true,
                    onProgressChange: (swiper) => {
                        for (var i = 0; i < swiper.slides.length; i++) {
                            var slide = swiper.slides[i];
                            var progress = slide.progress;
                            var translate = progress * swiper.width;
                            var opacity = 1 - Math.min(Math.abs(progress), 1);
                            slide.style.opacity = opacity;
                            swiper.setTransform(slide, 'translate3d(' + translate + 'px,0,0)');
                        }
                    },
                    onTouchStart: (swiper) => {
                        for (var i = 0; i < swiper.slides.length; i++) {
                            swiper.setTransition(swiper.slides[i], 0);
                        }
                    },
                    onSetWrapperTransition: (swiper, speed) => {
                        for (var i = 0; i < swiper.slides.length; i++) {
                            swiper.setTransition(swiper.slides[i], speed);
                        }
                    },
                };
                // add DOMs
                $tagWrapper.after(btnDOM + paginationDOM);
                // init btns
                $tag
                    .find('.btn-pre').on('click', (e) => {
                        e.preventDefault();
                        swiper.swipePrev();
                    })
                    .end()
                    .find('.btn-next').on('click', (e) => {
                        e.preventDefault();
                        swiper.swipeNext();
                    });
                // init swiper
                swiper = new Swiper(selector, options);
            }
        };
        swiperHandler($picHistory);
    }

    // product-box
    const $productBox = $('#product-box');
    if ($productBox.length) {
        const a = $productBox.find('a');

    }

    // agency-box
    const $agencyBox = $('#agency-box');
    console.log('$agencyBox:', $agencyBox.length);
    if ($agencyBox.length) {
        const $agencyBoxSidebarLi = $agencyBox.find('.agency-sidebar').find('li');
        const $agencyBoxItem = $agencyBox.find('.agency-item');
        // 自动分栏
        $agencyBoxItem.each((i, e) => {
            let $e = $(e);
            let $list = $e.find('.agency-list');
            let $li = $list.find('li');
            let liLen = $li.length;
            if (liLen > 10) {
                let dom = [
                    [],
                    []
                ];
                $li.each((i, e) => {
                    let n = 0;
                    if (i > 9) {
                        n = 1;
                    }
                    dom[n] += `<li>${$li.eq(i).html()}</li>`;
                });
                $e.html(`
                        <ul class="agency-list">${dom[0]}</ul>
                        <ul class="agency-list agency-list1">${dom[1]}</ul>`);
            }
        });

        // 绑定点击事件
        $agencyBoxSidebarLi.each((i, e) => {
            $(e).on('click', (e) => {
                $agencyBox.find('.active').removeClass('active');
                $agencyBoxSidebarLi.eq(i).addClass('active');
                $agencyBoxItem.eq(i).addClass('active');
            });
        });
    }
});
