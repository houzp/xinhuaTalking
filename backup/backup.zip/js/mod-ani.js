/**
 * Copyright (c) Xinhuanet Inc. All rights reserved.
 *
 * @License: MIT
 * @Author: SuperWoods
 * @Email:  st_sister@iCloud.com
 * @Date:   2016-09-27-04:46:21
 *
 * @(demo)Last modified by:   SuperWoods
 * @(demo)Last modified time: 2016-09-28-02:01:41
 */
// mod-ani
$(() => {
    const $productBox = $('#product-box');
    if ($productBox.length) {
        const DOMAniY = (tag, time, y, callback, ease) => {
            TweenMax.fromTo(tag, time, {
                css: {
                    y: y[0],
                }
            }, {
                css: {
                    y: y[1],
                },
                repeat: 0,
                yoyo: false,
                ease: (!ease) ? Power0.easeNone : ease,
                onComplete: callback,
            });
        };
        $productBox.on('mouseover', 'a', (e) => {
            let $e = $(e.target);
            // if (e.type === 'mouseover') {
            DOMAniY($e, .2, [0, 15], () => {
                DOMAniY($e, .2, [15, 0], () => {
                    DOMAniY($e, .2, [0, 15], () => {
                        DOMAniY($e, .2, [15, 0], null, null);
                    }, null);
                }, null);
            }, null);
            // } else if (e.type === 'mouseout') {
            //     // console.log('mouseout');
            //     // TweenMax.killAll();
            //     // DOMAniY($e, .1, [0, 0], null, null);
            // }
        });
    }
});
