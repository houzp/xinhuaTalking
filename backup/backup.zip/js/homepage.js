/**
 * Copyright (c) Xinhuanet Inc. All rights reserved.
 *
 * @License: MIT
 * @Author: SuperWoods
 * @Email:  st_sister@iCloud.com
 * @Date:   2016-09-12-10:28:24
 *
 * @(demo)Last modified by:   SuperWoods
 * @(demo)Last modified time: 2016-09-28-01:24:15
 */
// homepage
$(() => {
    // 设置俩个页面元素的高度 ------------------------------------------------------
    const $window = $(window);
    const windowSize = () => {
        return {
            width: $window.width(),
            height: $window.height(),
        };
    };
    const $building = $('#building');
    const $bgBuilding = $('#bg-building');

    // 比例计算
    const ratio = (opt) => {
        let $tag = opt.$tag;
        let oH = opt.orgHeight;
        let h = $tag.height();
        return (h / oH);
    };
    // 实例化两个 DOM 的比例
    const buildingRatio = ratio({
        $tag: $building,
        orgHeight: 1080
    });
    const bgBuildingRatio = ratio({
        $tag: $bgBuilding,
        orgHeight: 1080
    });

    // 设置高度
    let windowSizeObj;
    const setDOMSize = () => {
        windowSizeObj = windowSize();
        if (windowSizeObj.height < 1080) {
            $building.height(windowSizeObj.height * buildingRatio);
            $bgBuilding.height(windowSizeObj.height * bgBuildingRatio);
        } else {
            $building.removeAttr('style');
            $bgBuilding.removeAttr('style');
        }
        // console.log(windowSizeObj);
    };
    // onload
    setDOMSize();
    // onresize
    $window.on('resize', setDOMSize);

    // anis --------------------------------------------------------------------
    if (window.BROWSER.browser !== 'oldie') {
        // parallaxHandler
        const parallaxHandler = (_$) => {
            $(_$).parallax({
                // calibrateX: false,
                // calibrateY: true,
                // invertX: false,
                // invertY: true,
                // limitX: false,
                // limitY: 10,
                // scalarX: 2,
                // scalarY: 8,
                // frictionX: 0.2,
                // frictionY: 0.8,
                scalarX: 10,
                scalarY: 0,
            });
        };
        // init parallaxHandler
        parallaxHandler('#parallax-scene');

        // titleAni
        const $subtitle = $('#subtitle');
        // const $subtitleSpan = $subtitle.find('span');
        const $spriteTitleXinhua = $('.sprite-title-xinhua')
        const $spriteTitleAgency = $('.sprite-title-agency')
        const $news = $('.sprite-title-news, .sprite-title-news-bg')
        const $partNews = $('#part-news')

        let DOMArray = [
            $news,
            $spriteTitleXinhua,
            $spriteTitleAgency,
            $subtitle,
            // $subtitleSpan,
            $building,
            $bgBuilding,
            $partNews,
        ];

        const setAllOpcity = () => {
            $(DOMArray).each((i, e) => {
                e.css({
                    opacity: 0
                });
            });
        };
        setAllOpcity();

        const textAni = (tag, time, callback) => {
            TweenMax.fromTo(tag, time, {
                css: {
                    opacity: 0,
                }
            }, {
                css: {
                    opacity: 1,
                },
                repeat: 0,
                yoyo: false,
                ease: Power1.easeOut,
                onComplete: callback
            });
        };

        const DOMAni = (tag, time, x, callback, ease, isOnStart) => {
            let _callbacks = [null, null];
            if (isOnStart === 'isOnStart') {
                _callbacks[0] = callback;
            } else {
                _callbacks[1] = callback;
            }
            // TweenMax
            TweenMax.fromTo(tag, time, {
                css: {
                    opacity: 0,
                    x: x,
                }
            }, {
                css: {
                    opacity: 1,
                    x: 0,
                },
                repeat: 0,
                yoyo: false,
                ease: (!ease) ? Power0.easeNone : ease,
                onStart: _callbacks[0],
                onComplete: _callbacks[1],
            });
        };

        const DOMAniY = (tag, time, y, callback, ease) => {
            TweenMax.fromTo(tag, time, {
                css: {
                    opacity: 0,
                    y: y,
                }
            }, {
                css: {
                    opacity: 1,
                    y: 0,
                },
                repeat: 0,
                yoyo: false,
                ease: (!ease) ? Power0.easeNone : ease,
                onComplete: callback,
            });
        };

        // tests
        let testTimes = 0;
        let testSetInterval = null;

        const titleTime = 5;
        const titleAni = () => {
            // building
            DOMAni($building, 1, -300, () => {
                DOMAni($spriteTitleXinhua, titleTime * .9, -(windowSizeObj.width * .5), null, Elastic.easeOut.config(1, 0.75));
                DOMAni($spriteTitleAgency, titleTime * .4, windowSizeObj.width * .5, null, Elastic.easeOut.config(1, 0.75));
                DOMAni($subtitle, titleTime * 1, windowSizeObj.width * .5, null, Elastic.easeOut.config(1, 0.75));
                DOMAni($news, titleTime * 1.1, windowSizeObj.width * .5, () => {

                    // tests
                    testOnHandler();
                    console.log(`Well done!`);

                }, Elastic.easeOut.config(1, 0.75));
            }, Power1.easeOut);

            // bgBuilding
            TweenMax.delayedCall(titleTime * .1, () => {
                textAni($bgBuilding, titleTime, null);
            });

            // bgBuilding
            TweenMax.delayedCall(titleTime * .1, () => {
                DOMAniY($partNews, titleTime * .8, 200, null, Elastic.easeOut.config(1, 0.75));
            });
        };
        // init titleAni
        titleAni();

        // tests
        let testClearInterval = () => {
            clearInterval(testSetInterval);
            testSetInterval = null;
            testTimes = 0;
        }

        let testOnHandler = () => {
            console.log('test Ready!');
            testClearInterval();
        }

        let $body = $('body');
        $body.on('click', () => {
            $body.off('click');
            if (testSetInterval === null && testTimes === 0) {
                testSetInterval = setInterval(() => {
                    let t = testTimes++/ 10;
                    console.log(t);
                }, 100);
            }
            TweenMax.killAll();
            setAllOpcity();
            titleAni();
        });
    }
});
